import shop from '../../data/products';

//initial state
const state = {
    all: shop,
    type: 'all'
};

//getters
const getters = {
    allProducts: state => state.all,
};

//action
const actions = {
    getAllProducts({commit}){
        commit('getAllProducts', shop);
    }
};

//mutations
const mutations = {
    'getAllProducts'(state, {products}){
        state.all = products;
    },
    'setListType'(state, {type}){
        state.type = type;
    }
};

export default {
    state,
    // getters,
    // actions,
    mutations
};