//initial state
const state = {
    cart: [],
    total: 0,
};

//mutations
const mutations = {
    'addToCartNum'(state, {total}){
        state.total = total;
    },
    'addToCart'(state, {info}){
        state.cart.push[info];
    }
};

export default {
    state,
    // getters,
    // actions,
    mutations
};