<script>
import ProductList from './ProductList.vue';

export default {
  components:{
    ProductList
  }
}
</script>

<template>
  <div class="container">
    <ProductList></ProductList>
  </div>
</template>