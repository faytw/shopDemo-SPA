<template>
  <footer>
    <div class="inner-width">
      <p>Copyright © 2018 FaysPlayground All right reserved.</p>
    </div>
  </footer>
</template>

<style scoped>
footer{
  text-align: center;
  padding-top: 1em;
  padding-bottom: 1em;
  border-top: 1px solid #f5f5f5;
  font-size: 0.875em;
}
</style>
