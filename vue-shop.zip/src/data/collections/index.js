export default [
    {text:'所有商品', type:'all'},
    {text:'貓咪濕食', type:'canned'},
    {text:'貓咪乾糧', type:'dried'}
];