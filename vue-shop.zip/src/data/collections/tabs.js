export default [
    {type:'營養分析',view:'Nutrition'},
    {type:'商品評價',view:'Review'},
    {type:'購物說明',view:'Introduction'}
];